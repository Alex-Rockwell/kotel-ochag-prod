<template>
  <section class="garanty-documents">
    <div class="container">
      <h2 class="title-main service__title">Техническая документация</h2>
      <div class="service__wrapper">
        <div class="left-box">
          <h2 class="service__subtitle">Руководства по эксплуатации</h2>
          <ul class="service__manual-list">
            <li class="service__manual-item">
              <svg
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M11.5236 0V15.1176L8.6539 12.2798L7.51562 13.4068L12.3288 18.1665L17.142 13.4068L16.0037 12.2798L13.1339 15.1176V0H11.5236Z"
                  fill="#3c3f47"
                />
                <path
                  d="M17.9145 6.1744H23.0473V22.4066H1.61029V6.1744H6.74311V4.58105H0V23.9999H24.6576V4.58105H17.9145V6.1744Z"
                  fill="#3c3f47"
                />
              </svg>
              <a
                href="../../assets/files/docs/1.1-Аппарат отопительный газовый АОГВ (АКГВ) (на модели до 2021 года).pdf"
                class="service__manual-link"
                 
                >Аппарат отопительный газовый АОГВ (АКГВ) (на модели до 2021
                года)</a
              >
            </li>
            <li class="service__manual-item">
              <svg
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M11.5236 0V15.1176L8.6539 12.2798L7.51562 13.4068L12.3288 18.1665L17.142 13.4068L16.0037 12.2798L13.1339 15.1176V0H11.5236Z"
                  fill="#3c3f47"
                />
                <path
                  d="M17.9145 6.1744H23.0473V22.4066H1.61029V6.1744H6.74311V4.58105H0V23.9999H24.6576V4.58105H17.9145V6.1744Z"
                  fill="#3c3f47"
                />
              </svg>
              <a
                href="../../assets/files/docs/1.2-Аппарат отопительный газовый АОГВ (АКГВ).pdf"
                class="service__manual-link"
                 
                >Аппарат отопительный газовый АОГВ (АКГВ)</a
              >
            </li>
            <li class="service__manual-item">
              <svg
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M11.5236 0V15.1176L8.6539 12.2798L7.51562 13.4068L12.3288 18.1665L17.142 13.4068L16.0037 12.2798L13.1339 15.1176V0H11.5236Z"
                  fill="#3c3f47"
                />
                <path
                  d="M17.9145 6.1744H23.0473V22.4066H1.61029V6.1744H6.74311V4.58105H0V23.9999H24.6576V4.58105H17.9145V6.1744Z"
                  fill="#3c3f47"
                />
              </svg>
              <a
                href="../../assets/files/docs/1.3-Котел стальной газовый КСГ (КСГВ).pdf"
                class="service__manual-link"
                 
                >Котел стальной газовый КСГ (КСГВ)</a
              >
            </li>
            <li class="service__manual-item">
              <svg
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M11.5236 0V15.1176L8.6539 12.2798L7.51562 13.4068L12.3288 18.1665L17.142 13.4068L16.0037 12.2798L13.1339 15.1176V0H11.5236Z"
                  fill="#3c3f47"
                />
                <path
                  d="M17.9145 6.1744H23.0473V22.4066H1.61029V6.1744H6.74311V4.58105H0V23.9999H24.6576V4.58105H17.9145V6.1744Z"
                  fill="#3c3f47"
                />
              </svg>
              <a
                href="../../assets/files/docs/1.4-Аппарат отопительный газовый АОГВ 80 кВт и 98 кВт.pdf"
                class="service__manual-link"
                 
                >Аппарат отопительный газовый АОГВ 80 кВт и 98 кВт</a
              >
            </li>
            <li class="service__manual-item">
              <svg
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M11.5236 0V15.1176L8.6539 12.2798L7.51562 13.4068L12.3288 18.1665L17.142 13.4068L16.0037 12.2798L13.1339 15.1176V0H11.5236Z"
                  fill="#3c3f47"
                />
                <path
                  d="M17.9145 6.1744H23.0473V22.4066H1.61029V6.1744H6.74311V4.58105H0V23.9999H24.6576V4.58105H17.9145V6.1744Z"
                  fill="#3c3f47"
                />
              </svg>
              <a
                href="../../assets/files/docs/1.5-Котел парапетный газовый КСГЗ_2020.pdf"
                class="service__manual-link"
                 
                >Котел парапетный газовый КСГЗ</a
              >
            </li>
            <li class="service__manual-item">
              <svg
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M11.5236 0V15.1176L8.6539 12.2798L7.51562 13.4068L12.3288 18.1665L17.142 13.4068L16.0037 12.2798L13.1339 15.1176V0H11.5236Z"
                  fill="#3c3f47"
                />
                <path
                  d="M17.9145 6.1744H23.0473V22.4066H1.61029V6.1744H6.74311V4.58105H0V23.9999H24.6576V4.58105H17.9145V6.1744Z"
                  fill="#3c3f47"
                />
              </svg>
              <a
                href="../../assets/files/docs/1.6-Котел чугунный газовый.pdf"
                class="service__manual-link"
                 
                >Котел чугунный газовый</a
              >
            </li>
          </ul>
        </div>
        <div class="right-box">
          <h2 class="service__subtitle">Сертификаты</h2>
          <ul class="service__manual-list">
            <li class="service__manual-item">
              <svg
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M11.5236 0V15.1176L8.6539 12.2798L7.51562 13.4068L12.3288 18.1665L17.142 13.4068L16.0037 12.2798L13.1339 15.1176V0H11.5236Z"
                  fill="#3c3f47"
                />
                <path
                  d="M17.9145 6.1744H23.0473V22.4066H1.61029V6.1744H6.74311V4.58105H0V23.9999H24.6576V4.58105H17.9145V6.1744Z"
                  fill="#3c3f47"
                />
              </svg>
              <a
                href="../../assets/files/docs/2.1-Сертификат на напольные котлы КСГ(В), КЧГ, КСГЗ(В).pdf"
                class="service__manual-link"
                 
                >Сертификат на напольные котлы КСГ(В), КЧГ, КСГЗ(В)</a
              >
            </li>
            <li class="service__manual-item">
              <svg
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M11.5236 0V15.1176L8.6539 12.2798L7.51562 13.4068L12.3288 18.1665L17.142 13.4068L16.0037 12.2798L13.1339 15.1176V0H11.5236Z"
                  fill="#3c3f47"
                />
                <path
                  d="M17.9145 6.1744H23.0473V22.4066H1.61029V6.1744H6.74311V4.58105H0V23.9999H24.6576V4.58105H17.9145V6.1744Z"
                  fill="#3c3f47"
                />
              </svg>
              <a
                href="../../assets/files/docs/2.2-Cертификат на аппараты отопительные АОГВ и АКГВ_2020.pdf"
                class="service__manual-link"
                 
                >Cертификат на аппараты отопительные АОГВ и АКГВ</a
              >
            </li>
            <li class="service__manual-item">
              <svg
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M11.5236 0V15.1176L8.6539 12.2798L7.51562 13.4068L12.3288 18.1665L17.142 13.4068L16.0037 12.2798L13.1339 15.1176V0H11.5236Z"
                  fill="#3c3f47"
                />
                <path
                  d="M17.9145 6.1744H23.0473V22.4066H1.61029V6.1744H6.74311V4.58105H0V23.9999H24.6576V4.58105H17.9145V6.1744Z"
                  fill="#3c3f47"
                />
              </svg>
              <a
                href="../../assets/files/docs/2.3-Сертификат САБК.pdf"
                class="service__manual-link"
                 
                >Сертификат САБК</a
              >
            </li>
            <li class="service__manual-item">
              <svg
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M11.5236 0V15.1176L8.6539 12.2798L7.51562 13.4068L12.3288 18.1665L17.142 13.4068L16.0037 12.2798L13.1339 15.1176V0H11.5236Z"
                  fill="#3c3f47"
                />
                <path
                  d="M17.9145 6.1744H23.0473V22.4066H1.61029V6.1744H6.74311V4.58105H0V23.9999H24.6576V4.58105H17.9145V6.1744Z"
                  fill="#3c3f47"
                />
              </svg>
              <a
                href="../../assets/files/docs/2.4-Сертификат на устройства газогорелочные.pdf"
                class="service__manual-link"
                 
                >Сертификат на устройства газогорелочные</a
              >
            </li>
            <li class="service__manual-item">
              <svg
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M11.5236 0V15.1176L8.6539 12.2798L7.51562 13.4068L12.3288 18.1665L17.142 13.4068L16.0037 12.2798L13.1339 15.1176V0H11.5236Z"
                  fill="#3c3f47"
                />
                <path
                  d="M17.9145 6.1744H23.0473V22.4066H1.61029V6.1744H6.74311V4.58105H0V23.9999H24.6576V4.58105H17.9145V6.1744Z"
                  fill="#3c3f47"
                />
              </svg>
              <a
                href="../../assets/files/docs/2.5-ИСОRU.pdf"
                class="service__manual-link"
                 
                >Сертификаты ИСО (Рус)</a
              >
            </li>
            <li class="service__manual-item">
              <svg
                width="25"
                height="24"
                viewBox="0 0 25 24"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M11.5236 0V15.1176L8.6539 12.2798L7.51562 13.4068L12.3288 18.1665L17.142 13.4068L16.0037 12.2798L13.1339 15.1176V0H11.5236Z"
                  fill="#3c3f47"
                />
                <path
                  d="M17.9145 6.1744H23.0473V22.4066H1.61029V6.1744H6.74311V4.58105H0V23.9999H24.6576V4.58105H17.9145V6.1744Z"
                  fill="#3c3f47"
                />
              </svg>
              <a
                href="../../assets/files/docs/2.6-ИСОENG.pdf"
                class="service__manual-link"
                 
                >Сертификаты ИСО (Eng)</a
              >
            </li>
          </ul>
        </div>
      </div>
    </div>
    <GarantyModal :isOpen="isOpen" @closeModal="() => (isOpen = false)" />
  </section>
</template>

<script setup></script>

<style lang="scss" scoped>
.service__title {
  margin-bottom: 40px;

  @media (max-width: 900px) {
    margin-bottom: 15px;
  }
  @media (max-width: 450px) {
    margin-top: 25px;
  }
}
.service__wrapper {
  display: flex;

  & > *:first-child {
    flex-basis: 50%;
  }
  & > *:last-child {
    flex-basis: 50%;

    & > *:first-child {
      @media (max-width: 900px) {
        margin-top: 30px;
      }
    }
  }

  @media (max-width: 900px) {
    flex-direction: column;
  }
}

.service__subtitle {
  font-size: 24px;
  font-weight: 700;
  margin-bottom: 30px;
  padding-right: 15px;

  @media (max-width: 450px) {
    font-size: 20px;
    margin-bottom: 20px;
  }
}
.service__manual-list {
  list-style: none;
}
.service__manual-item {
  padding-top: 10px;
  padding-bottom: 10px;
  display: flex;
  align-items: flex-end;

  @media (max-width: 450px) {
    padding-top: 5px;
    padding-bottom: 5px;
  }

  & > svg {
    margin-right: 15px;
    align-self: center;
    flex-basis: 25px;
    flex-shrink: 0;
  }

  & > svg > * {
    transition: fill 0.3s ease;
  }
  &:hover > svg > * {
    fill: #00b2f6;
  }
  &:hover .service__manual-link {
    color: #00b2f6;
  }
}
.service__manual-link {
  color: inherit;
  text-decoration: none;
  transition: 0.3s ease;
  font-size: 16px;
  font-weight: 700;
  line-height: 1.5;
  max-width: 700px;
  padding-right: 15px;

  @media (max-width: 450px) {
    font-size: 12px;
  }
}
</style>
